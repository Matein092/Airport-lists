package model;


public class WindowPlane {
	
	private Flight firstF;
	private Flight lastF;
	
	public WindowPlane() {
		
	}
	
	public WindowPlane(Flight firstF) {
			this.firstF = firstF;
	}
	
	public void addFlightTop(Flight f) {
		if (firstF == null) {
			firstF = f;
		} else {
			Flight next = firstF;
			while (next.getNext() != null) {
				next = next.getNext();
			}
			next.setNext(f);
			f.setPrevious(next);
			lastF = f;
		}
	}
	
	public void addFlightLast(Flight f) {
		Flight last = lastFlight();
		if( last == null) {
			firstF = f;
		}else {
			last.setNext(f);
			f.setPrevious(last);
		}
	}
	
	public Flight lastFlight() {
		Flight actual = firstF;
		Flight prev = null;
		while(actual != null) {
			prev = actual;
			actual = actual.getNext();
		}
		return prev;
	}
	public void sortByDate() {
		while(firstF != null) {
			if(firstF.compareByDate(firstF.getNext()) == -1) {
				firstF.getNext().setNext(firstF);
				firstF.setPrevious(firstF.getNext());
				firstF = firstF.getNext();
			}
			else if(firstF.compareByDate(firstF.getNext()) == 1) {
				firstF.getNext().setPrevious(firstF);
				firstF.setNext(firstF.getNext());
			}
		}
	}
		
	
	public void sortByTime() {
		while(firstF != null) {
			if(firstF.compareByTime(firstF.getNext()) == -1) {
				firstF.getNext().setNext(firstF);
				firstF.setPrevious(firstF.getNext());
				firstF = firstF.getNext();
			}
			else if(firstF.compareByTime(firstF.getNext()) == 1) {
				firstF.getNext().setPrevious(firstF);
				firstF.setNext(firstF.getNext());
			}
		}
	}
	public void sortByFlight() {
		while(firstF != null) {
			if(firstF.compareByDate(firstF.getNext()) == -1) {
				firstF.getNext().setNext(firstF);
				firstF.setPrevious(firstF.getNext());
				firstF = firstF.getNext();
			}
			else if(firstF.compareByDate(firstF.getNext()) == 1) {
				firstF.getNext().setPrevious(firstF);
				firstF.setNext(firstF.getNext());
			}
		}
	}
	
	public void sortByDestination() {
		while(firstF != null) {
			if(firstF.compareByDestination(firstF.getNext()) == -1) {
				firstF.getNext().setNext(firstF);
				firstF.setPrevious(firstF.getNext());
				firstF = firstF.getNext();
			}
			else if(firstF.compareByDestination(firstF.getNext()) == 1) {
				firstF.getNext().setPrevious(firstF);
				firstF.setNext(firstF.getNext());
			}
		}
	}
	
	public void sortByGate() {
		while(firstF != null) {
			if(firstF.compareByGate(firstF.getNext()) == -1) {
				firstF.getNext().setNext(firstF);
				firstF.setPrevious(firstF.getNext());
				firstF = firstF.getNext();
			}
			else if(firstF.compareByGate(firstF.getNext()) == 1) {
				firstF.getNext().setPrevious(firstF);
				firstF.setNext(firstF.getNext());
			}
		}
	}
	
	public String drawFlights() {
		Flight next = firstF;
		String msg = "";
		while (next.getNext() != null) {
			msg = next.toString();
			next = next.getNext();
		}
		msg = next.toString();
		return msg;
	}
}
